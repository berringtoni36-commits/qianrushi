---
sourcePlugin: "multi-source-sync"
resourceId: "6a585e7c000000000f03cba8"
type: "收藏"
author: "数字生命卡兹克"
url: "https://www.xiaohongshu.com/explore/6a585e7c000000000f03cba8?xsec_token=AB-YMJcokH7AaLlB1bYeGP0ADSdg2l3yxRydwknelAIE8%3D"
tags:
  - "AI"
  - "AIChannel"
  - "AI工具"
  - "个人开发者"
  - "vibecoding"
  - "AI新手村"
  - "howto用好AI"
  - "人工智能"
  - "数字生命卡兹克"


postCreatedAt: 2026-07-16T04:30:52.000Z
syncedAt: 2026-08-13T18:30:31.073Z
accountId: "5bf3e0d514325800019f2ad7"
accountName: "。。。。。。。"
---

# 2026年，这可能是最爽的远程Coding方式...

作者：数字生命卡兹克


![[小红书（RedNote）/。。。。。。。/媒体（Media）/6a585e7c000000000f03cba8/image-1.jpg]]

![[小红书（RedNote）/。。。。。。。/媒体（Media）/6a585e7c000000000f03cba8/image-2.jpg]]

![[小红书（RedNote）/。。。。。。。/媒体（Media）/6a585e7c000000000f03cba8/image-3.jpg]]

![[小红书（RedNote）/。。。。。。。/媒体（Media）/6a585e7c000000000f03cba8/image-4.jpg]]

![[小红书（RedNote）/。。。。。。。/媒体（Media）/6a585e7c000000000f03cba8/image-5.jpg]]

![[小红书（RedNote）/。。。。。。。/媒体（Media）/6a585e7c000000000f03cba8/image-6.jpg]]

![[小红书（RedNote）/。。。。。。。/媒体（Media）/6a585e7c000000000f03cba8/image-7.jpg]]

![[小红书（RedNote）/。。。。。。。/媒体（Media）/6a585e7c000000000f03cba8/image-8.jpg]]

![[小红书（RedNote）/。。。。。。。/媒体（Media）/6a585e7c000000000f03cba8/image-9.jpg]]

![[小红书（RedNote）/。。。。。。。/媒体（Media）/6a585e7c000000000f03cba8/image-10.jpg]]

![[小红书（RedNote）/。。。。。。。/媒体（Media）/6a585e7c000000000f03cba8/image-11.jpg]]

![[小红书（RedNote）/。。。。。。。/媒体（Media）/6a585e7c000000000f03cba8/image-12.jpg]]

![[小红书（RedNote）/。。。。。。。/媒体（Media）/6a585e7c000000000f03cba8/image-13.jpg]]

![[小红书（RedNote）/。。。。。。。/媒体（Media）/6a585e7c000000000f03cba8/image-14.jpg]]

![[小红书（RedNote）/。。。。。。。/媒体（Media）/6a585e7c000000000f03cba8/image-15.jpg]]

![[小红书（RedNote）/。。。。。。。/媒体（Media）/6a585e7c000000000f03cba8/image-16.jpg]]

![[小红书（RedNote）/。。。。。。。/媒体（Media）/6a585e7c000000000f03cba8/image-17.jpg]]

![[小红书（RedNote）/。。。。。。。/媒体（Media）/6a585e7c000000000f03cba8/image-18.jpg]]

![[小红书（RedNote）/。。。。。。。/媒体（Media）/6a585e7c000000000f03cba8/image-19.jpg]]

![[image-20.jpg]]

![[image-21.jpg]]

![[image-22.jpg]]

昨天那篇文章，我说了一下我现在用Agent的日常。
为了不浪费Agent的时间和Token，我几乎不管在路上、在外面，都在让Agent干活。
	
然后评论区居然有好几个朋友问教程。
	
那自然，是有求必应。
	
所以今天我觉得可以给大家分享一下，我自己这一整套远程使用Agent干活的组合和流程，而且支持多设备协同，你完全不需要考虑什么.md文件、Agent记忆、Skill同步之类的问题，我自己觉得特别适合我自己，也安利公司小伙伴所有人在用。
	
且不止是Vibe Coding，其实用Agent干所有的日常任务，比如知识处理、数据分析等等的所有任务，都可以让你远程拿着手机处理掉一切，完全没有任何问题。
	
核心其实就是两个东西，Codex主力操控 + UU远程兜底（我对天发誓这不是UU远程的广，是它真的很好用）。
	
这两个东西的定位不太一样，我一个一个说，但是组合起来，是真的无敌。
	
话不多说，我们正文见！
	
如果觉得有用的话，欢迎把它分享给你的朋友们一起看看，这对我们有特别大的帮助！
	
#AI[话题]# #AIChannel[话题]# #AI工具[话题]# #个人开发者[话题]# #vibecoding[话题]# #AI新手村[话题]# #howto用好AI[话题]# #人工智能[话题]# #数字生命卡兹克[话题]# @HOWTO薯



## 评论

- **个别同志** · 2026-07-21T01:13:57.000Z · 71 赞：UU远程好用到我怀疑开发人员是做给自己用的，顺便领工资，没有任何盈利点，全是以人为本的功能优化。
- **YAMMY** · 2026-07-17T02:06:05.000Z · 18 赞：好奇你们都用agent干啥活儿？我作为一个互联网牛马，平时就上下班，完全没啥想法
- **Daniel勇闯独立站** · 2026-07-16T12:58:42.000Z · 3 赞：uu 远程会比向日葵好用吗？
- **小源杂谈** · 2026-07-16T05:10:48.000Z · 17 赞：我是用Workbuddy的，出门在外就用微信对话给电脑端发指令，如果需要看一下电脑屏幕，就用手机自带的同屏功能远程操作电脑，就是手机屏幕小，有的时候需要放大一下才能找到按钮。
- **迈巴赫钠思** · 2026-08-13T05:44:43.000Z · 0 赞：以前一直用moonlight+sunshine玩串流游戏，这么一看uu好像也能用而且还不需要配置公网IP啥的。早知道就不折腾moonlight那些了
- **温言** · 2026-07-16T06:08:02.000Z · 6 赞：笑死 居然卡神和我方案一模一样[doge]，我也在用 uu，出差电脑也不背，就一个 ipad mini 和折叠键盘，还有 ar 眼镜，需要的时候展开带上就可以 vibe 了
- **小红薯690AB0B0** · 2026-07-17T02:39:28.000Z · 2 赞：电脑必须永远开机？
- **灵嘎嘎** · 2026-07-26T01:33:02.000Z · 0 赞：codex需要国外验证码登录
- **0o** · 2026-08-08T09:32:09.000Z · 0 赞：Codex接飞书，做好会话维持就行了
- **阿白** · 2026-08-01T00:40:26.000Z · 0 赞：那么多需求吗

原文：https://www.xiaohongshu.com/explore/6a585e7c000000000f03cba8?xsec_token=AB-YMJcokH7AaLlB1bYeGP0ADSdg2l3yxRydwknelAIE8%3D
