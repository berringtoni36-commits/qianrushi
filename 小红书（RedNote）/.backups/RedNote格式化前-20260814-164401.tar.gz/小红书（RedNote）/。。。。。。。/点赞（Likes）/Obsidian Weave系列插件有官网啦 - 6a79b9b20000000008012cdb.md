---
sourcePlugin: "multi-source-sync"
resourceId: "6a79b9b20000000008012cdb"
type: "点赞"
author: "粗言细语"
url: "https://www.xiaohongshu.com/explore/6a79b9b20000000008012cdb?xsec_token=ABH6H5Dgn5wxcps-Vae_DflgRbz5JVeasXQeQp1ypUPJo%3D"
tags:
  - "obsidian插件"
  - "颜值"
  - "终生学习"
  - "高效生产力"
  - "官网"
  - "性价比高"
  - "宝藏插件"


postCreatedAt: 2026-08-10T11:44:50.000Z
syncedAt: 2026-08-13T15:39:36.444Z
accountId: "5bf3e0d514325800019f2ad7"
accountName: "。。。。。。。"
---

# Obsidian Weave系列插件有官网啦

作者：粗言细语


![[小红书（RedNote）/。。。。。。。/媒体（Media）/6a79b9b20000000008012cdb/image-1.jpg]]

![[小红书（RedNote）/。。。。。。。/媒体（Media）/6a79b9b20000000008012cdb/image-2.jpg]]

![[小红书（RedNote）/。。。。。。。/媒体（Media）/6a79b9b20000000008012cdb/image-3.jpg]]

![[小红书（RedNote）/。。。。。。。/媒体（Media）/6a79b9b20000000008012cdb/image-4.jpg]]

![[小红书（RedNote）/。。。。。。。/媒体（Media）/6a79b9b20000000008012cdb/image-5.jpg]]

![[小红书（RedNote）/。。。。。。。/媒体（Media）/6a79b9b20000000008012cdb/image-6.jpg]]

![[小红书（RedNote）/。。。。。。。/媒体（Media）/6a79b9b20000000008012cdb/image-7.jpg]]

![[小红书（RedNote）/。。。。。。。/媒体（Media）/6a79b9b20000000008012cdb/image-8.jpg]]

#obsidian插件[话题]# #颜值[话题]# #终生学习[话题]# #高效生产力[话题]# #官网[话题]# #性价比高[话题]# #宝藏插件[话题]#
	
https://zhuzhige123.github.io/obsidian-weave-website/#pricing





原文：https://www.xiaohongshu.com/explore/6a79b9b20000000008012cdb?xsec_token=ABH6H5Dgn5wxcps-Vae_DflgRbz5JVeasXQeQp1ypUPJo%3D
